DOMAIN = "state_grid"
PACKAGE_NAME = "custom_components.state_grid"
VERSION = "0.0.6"
VERSION_STORAGE = 1
